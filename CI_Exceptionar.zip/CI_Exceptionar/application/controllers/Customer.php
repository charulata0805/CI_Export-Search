<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
//require(APPPATH.'third_party/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');

class Customer extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('customer_model');
	}

	public function index(){
		$data['cust'] = $this->customer_model->getAllUsers();
		$this->load->view('customer_list.php', $data);
	}



	public function createExcel() {
	
	 		require(APPPATH.'third_party/PHPExcel-1.8/Classes/PHPExcel.php');      
	 		require(APPPATH.'third_party/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');

		$fileName = 'data-'.time().'.xls';   
		$CData = $this->customer_model->custList();
		$objPHPExcel = new PHPExcel();



        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->getActiveSheet()->SetCellValue('A1','cust_name');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1','product_no');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1','amount_balance');
        $objPHPExcel->getActiveSheet()->SetCellValue('D1','value_no');
        $objPHPExcel->getActiveSheet()->SetCellValue('E1','company');
        $objPHPExcel->getActiveSheet()->SetCellValue('F1','category');


        $rows = 2;
      //print_r($CData);


       foreach ($CData as  $val)
        {  
           $objPHPExcel->getActiveSheet()->SetCellValue('A'. $rows,$val->cust_name);
           $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rows, $val->product_no);
           $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rows, $val->amount_balance);
           $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rows, $val->value_no);
           $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rows, $val->company);
           $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rows, $val->category);
            $rows++;
        } 

         $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $objWriter->save($fileName);
  
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Type: application/vnd.ms-excel'); 
        header('Content-Disposition: attachment;filename="'.$fileName.'"');
        header('Cache-Control: max-age=0'); 

   
                 
    }  

    public function search()
   {

    $this->load->model('customer_model');
    $search = $this->input->post('search');

    // echo "kkk".$search;
    $data['cust'] =  $this->customer_model->search($search);
    $this->load-view('search.php',$data);
    
  }  
	
	
}


?>
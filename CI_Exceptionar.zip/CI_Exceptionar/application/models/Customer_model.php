<?php
	class Customer_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function getAllUsers(){
			$query = $this->db->get('customes');
			return $query->result(); 
		}
		
		public function custList() 
		{

	    $this->db->select(array('cust_name','product_no','amount_balance','value_no','company','category'));
		$this->db->from('customes');
		//$this->db->limit(10);  
		$query = $this->db->get();
		return $query->result_array();

	  }


	   public function search($search)
		{
		    $this->db->select('*');
		    $this->db->from('customes');
		    $this->db->like('cust_name',$search);
		    //$this->db->or_like('product_no',$search);
		   // $this->db->or_like('amount_balance',$search);
		   // $this->db->or_like('value_no',$search);
		      // $this->db->or_like('company',$search);
		     // $this->db->or_like('category',$search);
		    $query = $this->db->get();
		    return $query->result();

		}

		
	}
?>
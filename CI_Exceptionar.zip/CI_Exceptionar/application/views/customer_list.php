<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CodeIgniter  Task</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>

<body>
<div class="container">
	<h1 class="page-header text-center">CodeIgniter  Task</h1>
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2"><a class="pull-right btn btn-warning btn-large" style="margin-right:40px" href="<?php echo site_url(); ?>/customer/createexcel"><i class="fa fa-file-excel-o"></i> Export</a>
</div>
</div>
     <form action="<?php echo site_url(); ?>/customer/search" method="post"> 
        <div class="input-group"> 
        <input type="text" name="search" class="form-control" placeholder="Search">
        </div>
        <div class="input-group">
        <input type="submit" value="search" name="save"/>
        </div>
        </form>

			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<th>ID</th>
						<th>Customsername</th>
						<th>Product</th>
						<th>Amolunt</th>
						<th>Value</th>
						<th>Company</th>
						<th>Category</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($cust as $c){
						?>
						<tr>
							<td><?php echo $c->id; ?></td>
							<td><?php echo $c->cust_name; ?></td>
							<td><?php echo $c->product_no; ?></td>
							<td><?php echo $c->amount_balance; ?></td>
							<td><?php echo $c->value_no; ?></td>
							<td><?php echo $c->company; ?></td>
							<td><?php echo $c->category; ?></td>
							
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
</body>
</html>
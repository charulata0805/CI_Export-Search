 <!DOCTYPE html>
 <html>
 <head>
   <title>he</title>
 </head>
 <body>
 

  <table>
      <tr>
          <td>User Name</td>
        
      </tr>
<?php foreach($cust as $c) ?>
      <tr>
          <td><?php echo $c->cust_name?></td>
          
      </tr>
<?php endforeach ?>

 </table>
 <?php   echo "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"; ?>
 
 </body>
 </html>